#ifndef _BASICS_H_
#define _BASICS_H_

#include <stdbool.h>

void welcome_msg();
void d_collect_msg(long*);
void print_json(char*);
void udelay_basics (long);
long take_time_basics();
void print_sensors_state(void);

#endif
