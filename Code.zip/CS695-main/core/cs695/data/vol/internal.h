#ifndef _INTERNAL_H_
#define _INTERNAL_H_

char* get_internal();

#endif