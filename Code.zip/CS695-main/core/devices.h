#ifndef _DEVICES_H_
#define _DEVICES_H_
#ifdef BBBW
	#include "cs695/cs695-headers.h"
#endif
#endif
